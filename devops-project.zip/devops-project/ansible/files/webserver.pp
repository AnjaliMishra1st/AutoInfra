# Puppet manifest: keeps Apache installed, running and serving the right page
class webserver {
  $host = $facts['networking']['hostname']

  package { 'apache2':
    ensure => installed,
  }

  file { '/var/www/html/index.html':
    ensure  => file,
    content => "<h1>DevOps Project - Anjali Mishra (Roll 13)</h1><p>Served by ${host} and managed by Puppet</p>\n",
    require => Package['apache2'],
    notify  => Service['apache2'],
  }

  service { 'apache2':
    ensure   => running,
    provider => 'init',   # containers have no systemd
    require  => Package['apache2'],
  }
}

include webserver
